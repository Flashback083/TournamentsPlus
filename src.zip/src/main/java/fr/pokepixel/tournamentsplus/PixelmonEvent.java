package fr.pokepixel.tournamentsplus;

import com.google.common.collect.Lists;
import com.hiroku.tournaments.api.events.match.MatchStartEvent;
import com.hiroku.tournaments.api.events.tournament.JoinTournamentEvent;
import com.hiroku.tournaments.api.events.tournament.TournamentStartEvent;
import com.hiroku.tournaments.obj.Side;
import com.pixelmonmod.pixelmon.Pixelmon;
import com.pixelmonmod.pixelmon.api.pokemon.Pokemon;
import com.pixelmonmod.pixelmon.api.pokemon.PokemonSpec;
import com.pixelmonmod.pixelmon.storage.PlayerPartyStorage;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.common.config.ConfigCategory;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.spongepowered.api.entity.living.player.Player;
import org.spongepowered.api.text.Text;

import java.util.ArrayList;

public class PixelmonEvent {

    @SubscribeEvent
    public void onTournamentJoin(JoinTournamentEvent event){
        Configuration config = TournamentsPlus.config;
        ConfigCategory cfg = config.getCategory("TournamentsPlusConfig");
        ArrayList<String> spec = Lists.newArrayList(cfg.get("listspecbanned").getStringList());
        Player player = event.team.users.get(0).getPlayer().get();
        System.out.println(player.getName());
        PlayerPartyStorage pStorage = Pixelmon.storageManager.getParty(player.getUniqueId());
        for (int i = 0; i < 6; i++){
            Pokemon pokemon = pStorage.get(i);
            int finalI = i;
            spec.forEach(speclist ->{
                if (new PokemonSpec(speclist).matches(pokemon)){
                    int slot = finalI + 1;
                    player.sendMessage(Text.of(TextFormatting.RED + "You can't join the tournament, one pokemon of your team doesnt match with the rules of the tournaments (Slot: " + slot + ")"));
                    event.setCanceled(true);
                }
            });
        }
    }


    /*@SubscribeEvent
    public void onTournamentStart(MatchStartEvent event){
        Configuration config = TournamentsPlus.config;
        ConfigCategory cfg = config.getCategory("TournamentsPlusConfig");
        ArrayList<String> spec = Lists.newArrayList(cfg.get("listspecbanned").getStringList());
        for (int i = 0; i < event.match.getNumPlayers(true);i++){
            int team = event.match.getOtherSide(event.match.sides[0]).teams.length;
            for (int j = 0; j < team; j++){
                Player player = event.match.getOtherSide(event.match.sides[0]).teams[j].users.get(0).getPlayer().get();
                PlayerPartyStorage pStorage = Pixelmon.storageManager.getParty(player.getUniqueId());
                for (int k = 0; k < 6; k++){
                    Pokemon pokemon = pStorage.get(i);
                    int finalK = k;
                    spec.forEach(speclist ->{
                        if (new PokemonSpec(speclist).matches(pokemon)){
                            int slot = finalK +1;
                            player.sendMessage(Text.of(TextFormatting.RED + "You can't join the tournament, one pokemon of your team doesnt match with the rules of the tournaments (Slot: " + slot + ")"));
                            event.setCanceled(true);
                        }
                    });
                }
            }
        }
    }*/

}
