package fr.pokepixel.tournamentsplus;

import net.minecraftforge.common.config.Configuration;
import org.apache.logging.log4j.Level;

public class Config {

   
    private static final String CATEGORY = "TournamentsPlusConfig";

    private static String[] listspecbanned = new String[]{};


    public static void readConfig() {
        Configuration cfg = TournamentsPlus.config;
        try {
            cfg.load();   
            initWhitelistConfig(cfg);
        } catch (Exception e1) {
            TournamentsPlus.logger.log(Level.ERROR, "Problem loading config file!", e1);
        } finally {
            if (cfg.hasChanged()) {
                cfg.save();
            }
        }    
    }
  
    private static void initWhitelistConfig(Configuration cfg) {
        cfg.addCustomCategoryComment(CATEGORY, CATEGORY);
        listspecbanned = cfg.getStringList("listspecbanned", CATEGORY, listspecbanned,"List of pokemon (as spec) which will be banned from Tournament plugin");
    }
}
